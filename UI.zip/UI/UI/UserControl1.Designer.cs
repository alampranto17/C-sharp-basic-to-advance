﻿namespace UI
{
    partial class UserControl1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.button1 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ewrewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rweToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rweToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.rweToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.rweToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.rweToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.wreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.ContextMenuStrip = this.contextMenuStrip1;
            this.pictureBox1.Location = new System.Drawing.Point(4, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(287, 316);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(4, 334);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(206, 23);
            this.progressBar1.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(216, 334);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.changeToolStripMenuItem,
            this.updateToolStripMenuItem,
            this.ewrewToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(116, 114);
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.newToolStripMenuItem.Text = "New";
            // 
            // changeToolStripMenuItem
            // 
            this.changeToolStripMenuItem.Name = "changeToolStripMenuItem";
            this.changeToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.changeToolStripMenuItem.Text = "Change";
            this.changeToolStripMenuItem.Click += new System.EventHandler(this.changeToolStripMenuItem_Click);
            // 
            // updateToolStripMenuItem
            // 
            this.updateToolStripMenuItem.Name = "updateToolStripMenuItem";
            this.updateToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.updateToolStripMenuItem.Text = "Update";
            // 
            // ewrewToolStripMenuItem
            // 
            this.ewrewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rweToolStripMenuItem,
            this.rweToolStripMenuItem1,
            this.rweToolStripMenuItem2});
            this.ewrewToolStripMenuItem.Name = "ewrewToolStripMenuItem";
            this.ewrewToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ewrewToolStripMenuItem.Text = "ewrew";
            // 
            // rweToolStripMenuItem
            // 
            this.rweToolStripMenuItem.Name = "rweToolStripMenuItem";
            this.rweToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.rweToolStripMenuItem.Text = "rwe";
            // 
            // rweToolStripMenuItem1
            // 
            this.rweToolStripMenuItem1.Name = "rweToolStripMenuItem1";
            this.rweToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.rweToolStripMenuItem1.Text = "rwe";
            // 
            // rweToolStripMenuItem2
            // 
            this.rweToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rweToolStripMenuItem3,
            this.rweToolStripMenuItem4,
            this.wreToolStripMenuItem});
            this.rweToolStripMenuItem2.Name = "rweToolStripMenuItem2";
            this.rweToolStripMenuItem2.Size = new System.Drawing.Size(180, 22);
            this.rweToolStripMenuItem2.Text = "rwe";
            // 
            // rweToolStripMenuItem3
            // 
            this.rweToolStripMenuItem3.Name = "rweToolStripMenuItem3";
            this.rweToolStripMenuItem3.Size = new System.Drawing.Size(180, 22);
            this.rweToolStripMenuItem3.Text = "rwe";
            // 
            // rweToolStripMenuItem4
            // 
            this.rweToolStripMenuItem4.Name = "rweToolStripMenuItem4";
            this.rweToolStripMenuItem4.Size = new System.Drawing.Size(180, 22);
            this.rweToolStripMenuItem4.Text = "rwe";
            // 
            // wreToolStripMenuItem
            // 
            this.wreToolStripMenuItem.Name = "wreToolStripMenuItem";
            this.wreToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.wreToolStripMenuItem.Text = "wre";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(61, 4);
            // 
            // UserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "UserControl1";
            this.Size = new System.Drawing.Size(294, 375);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ewrewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rweToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rweToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem rweToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem rweToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem rweToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem wreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
    }
}
