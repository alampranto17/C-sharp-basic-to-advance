﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            this.button1.BackColor = Color.Brown;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            this.button1.BackColor = SystemColors.Control;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            if (DialogResult.OK == cd.ShowDialog())
                this.panel1.BackColor = cd.Color;
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            this.label1.Text = this.trackBar1.Value.ToString();
            this.panel2.BackColor = Color.FromArgb(this.trackBar1.Value, 0, 0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UserControl1 uc1 = new UserControl1();
            this.panel3.Controls.Add(uc1);
        }
    }
}
