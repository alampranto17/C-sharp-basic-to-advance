﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleAppAMDPro;

namespace ClassLib
{
    class University : Student
    {
        public int m;
        private int n;
        protected int o;
        internal int p;
        protected internal int q;

        void M2()
        {
            
        }
    }
}
