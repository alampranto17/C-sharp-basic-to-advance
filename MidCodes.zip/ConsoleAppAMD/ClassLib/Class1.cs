﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib
{
    public class Class1
    {
        void F()
        {
            University u = new University();
        }
    }
}
