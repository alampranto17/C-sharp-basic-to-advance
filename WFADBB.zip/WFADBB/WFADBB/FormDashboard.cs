﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFADBB
{
    public partial class FormDashboard : Form
    {
        private DataAccess Da { get; set; }

        public FormDashboard()
        {
            InitializeComponent();
            this.Da = new DataAccess();

            this.PopulateGridView();
        }

        private void PopulateGridView(string sql = "select * from Movie;")
        {
            var ds = this.Da.ExecuteQuery(sql);

            this.dgvMovie.AutoGenerateColumns = false;
            this.dgvMovie.DataSource = ds.Tables[0];
        }

        private void btnShowDetails_Click(object sender, EventArgs e)
        {
            this.PopulateGridView();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string sql = "select * from Movie where genre = '" + this.txtSearch.Text + "';";
            this.PopulateGridView(sql);
        }

        private void txtAutoSearch_TextChanged(object sender, EventArgs e)
        {
            var sql = "select * from Movie where Title like '" + this.txtAutoSearch.Text + "%';";
            this.PopulateGridView(sql);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if(!this.IsValidToSave())
                {
                    MessageBox.Show("Please fill all the fields");
                    return;
                }

                var query = "select * from Movie where Id = '" + this.txtID.Text + "';";
                var ds = this.Da.ExecuteQuery(query);
                if(ds.Tables[0].Rows.Count == 1)
                {
                    //update
                    var sql = @"update Movie
                                set Title = '" + this.txtTitle.Text + @"',
                                IMDB = " + this.txtIMDB.Text + @",
                                Income = " + this.txtIncome.Text + @",
                                ReleaseDate = '" + this.dtpReleaseDate.Text + @"',
                                Genre = '" + this.cmbGenre.Text + @"'
                                where Id = '" + this.txtID.Text + "'; ";
                    var count = this.Da.ExecuteDMLQuery(sql);

                    if (count == 1)
                        MessageBox.Show("Data has been updated properly");
                    else
                        MessageBox.Show("Data hasn't been updated properly");

                }
                else
                {
                    //insert
                    var sql = "insert into Movie values('" + this.txtID.Text + "', '" + this.txtTitle.Text + "', " + this.txtIMDB.Text + ", " + this.txtIncome.Text + ", '" + this.dtpReleaseDate.Text + "', '" + this.cmbGenre.Text + "'); ";
                    var count = this.Da.ExecuteDMLQuery(sql);

                    if (count == 1)
                        MessageBox.Show("Data has been added properly");
                    else
                        MessageBox.Show("Data hasn't been added properly");

                }
                this.PopulateGridView();
            }
            catch(Exception exc)
            {
                MessageBox.Show("An error has occurred. Please check: " + exc.Message);
            }            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.txtID.Clear();
            this.txtTitle.Text = "";
            this.txtIMDB.Clear();
            this.txtIncome.Clear();
            this.dtpReleaseDate.Text = "";
            this.cmbGenre.SelectedIndex = -1;

            this.txtSearch.Clear();
            this.txtAutoSearch.Clear();
        }

        private bool IsValidToSave()
        {
            if (string.IsNullOrEmpty(this.txtID.Text) || string.IsNullOrEmpty(this.txtTitle.Text) ||
                string.IsNullOrEmpty(this.txtIMDB.Text) || string.IsNullOrEmpty(this.txtIncome.Text) ||
                string.IsNullOrEmpty(this.cmbGenre.Text))
                return false;
            else
                return true;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if(this.dgvMovie.SelectedRows.Count < 1)
                {
                    MessageBox.Show("Please select a row first to delete.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var id = this.dgvMovie.CurrentRow.Cells[0].Value.ToString();
                var title = this.dgvMovie.CurrentRow.Cells[1].Value.ToString();
                //MessageBox.Show(id);

                DialogResult result = MessageBox.Show("Are you sure you want to delete "+title+"?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.No)
                {
                    return;
                }

                var sql = "delete from Movie where Id = '" + id + "';";
                var count = this.Da.ExecuteDMLQuery(sql);
                if (count == 1)
                    MessageBox.Show(title.ToUpper() + " has been removed properly from the list.");
                else
                    MessageBox.Show("Data hasn't been removed properly");

                this.PopulateGridView();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occurred. Please check: " + exc.Message);
            }            
        }

        private void FormDashboard_Load(object sender, EventArgs e)
        {
            this.dgvMovie.ClearSelection();
        }

        private void dgvMovie_DoubleClick(object sender, EventArgs e)
        {
            this.txtID.Text = this.dgvMovie.CurrentRow.Cells[0].Value.ToString();
            this.txtTitle.Text = this.dgvMovie.CurrentRow.Cells[1].Value.ToString();
            this.txtIMDB.Text = this.dgvMovie.CurrentRow.Cells[2].Value.ToString();
            this.txtIncome.Text = this.dgvMovie.CurrentRow.Cells[3].Value.ToString();
            this.dtpReleaseDate.Text = this.dgvMovie.CurrentRow.Cells[4].Value.ToString();
            this.cmbGenre.Text = this.dgvMovie.CurrentRow.Cells[5].Value.ToString();
        }
    }
}
